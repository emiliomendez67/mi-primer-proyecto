/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio03;

import java.util.Scanner;

/**
 *
 * @author PC TECHNOLOGY
 */
public class Ejercicio03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        int edad;
        System.out.print("ingrese su edad:");
        edad=sc.nextInt();
        
        if (edad>=18){
            System.out.println("Es mayor de edad");
        }
            
    }
    
}
