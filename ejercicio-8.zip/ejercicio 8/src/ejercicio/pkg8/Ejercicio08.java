/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg8;

import java.util.Scanner;

/**
 *
 * @author PC TECHNOLOGY
 */
public class Ejercicio08 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String contrasena;
        do{
            System.out.print("Ingrese la contraseña: ");
            contrasena=sc.nextLine();
        }while (!contrasena.equals("java2026"));
        
        System.out.println("Acceso Concedido");
    }
    
}
