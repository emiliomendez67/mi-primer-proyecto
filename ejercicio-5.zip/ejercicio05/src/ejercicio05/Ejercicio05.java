/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio05;

import java.util.Scanner;

/**
 *
 * @author PC TECHNOLOGY
 */
public class Ejercicio05 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double nota;
        System.out.print("ingrese la calificacion:");
        nota=sc.nextDouble();
        
        if (nota>=9){
            System.out.println("EXCELENTE");
        }else if(nota>=8){
            System.out.println("MUY BUENO");    
        }else if(nota>=7){
            System.out.println("BUENO");
        }else if(nota>=5){
            System.out.println("REGULAR");
        }else if(nota>=0){
            System.out.println("DEFICIENTE");
        }
        
       
    }
    
}
