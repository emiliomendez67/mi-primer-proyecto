/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio11;

import java.util.Scanner;

/**
 *
 * @author PC TECHNOLOGY
 */
public class Ejercicio11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
         int num,mayor=0,menor=0;
        
         for (int i=1; i <=10; i++){
             System.out.print("Ingrese numero "+ i + "-10:");
             num=sc.nextInt();
             
              if (i == 1) {
                mayor = num;
                menor = num;
            } else {
             if (num>mayor){
                 mayor=num;
             }
             if (num<menor){
                 menor=num;
             }  
            }
         }   
       System.out.println("El numero mayor es:"+ mayor);
       System.out.println("El numero menor es:"+ menor);  
    }
    
}
