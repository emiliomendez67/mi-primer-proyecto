/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio04;

import java.util.Scanner;

/**
 *
 * @author PC TECHNOLOGY
 */
public class Ejercicio04 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);
         double nota;
         System.out.print("Ingrese su nota:");
         nota=sc.nextDouble();
         if (nota>=7) {
             System.out.println("Aprobado");
        }else{
             System.out.println("Reprobado");
             
         }
    }
    
}
