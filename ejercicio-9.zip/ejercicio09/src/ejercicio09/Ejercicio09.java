/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio09;

import java.util.Scanner;

/**
 *
 * @author PC TECHNOLOGY
 */
public class Ejercicio09 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num;
      
        System.out.print("Ingrese un numero: ");
        num=sc.nextInt();
        System.out.println("\n==TABLA DE MULTIPLICACION==");
        for (int i=1; i <= 12; i++){
            System.out.println(num +"x"+ i + "=" + (num*i));
        }
    }
    
}
