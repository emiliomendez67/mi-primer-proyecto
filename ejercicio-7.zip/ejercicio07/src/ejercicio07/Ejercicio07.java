/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio07;

import java.util.Scanner;

/**
 *
 * @author PC TECHNOLOGY
 */
public class Ejercicio07 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num;
        int contador=0,suma=0;
        do{         
            System.out.print("Ingrese un numero positivo: ");
            num=sc.nextInt();
            if (num>=0){
               contador++;
               suma+=num;
            }
        }while (num>=0);   
       
        System.out.println("La cantidad de numeros ingresados es:"+contador);
        System.out.println("la suma total es:"+suma);
    }
} 

        
    
    

