/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio02;

import java.util.Scanner;

/**
 *
 * @author PC TECHNOLOGY
 */
public class Ejercicio02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
       
        int num1,num2;
        System.out.print("ingrese el primer numero:");
        num1=sc.nextInt();
        
        System.out.print("ingrese el segundo numero:");
        num2=sc.nextInt();
        
        System.out.println("=====OPERACIONES=======");
        System.out.println("La suma es:"+(num1+num2));      
        System.out.println("La resta es:"+(num1-num2));       
        System.out.println("La multiplicacion es:"+(num1*num2));        
        System.out.println("La division es:"+(num1/num2));
        System.out.println("El residuo es:"+(num1%num2));
                 
                
    }    
    
}
