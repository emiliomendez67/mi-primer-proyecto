/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio10;

import java.util.Scanner;

/**
 *
 * @author PC TECHNOLOGY
 */
public class Ejercicio10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);
         int num,suma=0;
         double prom;
      
         for (int i=1; i <=10; i++){
             System.out.print("Ingrese numero "+ i + "-10:");
             num=sc.nextInt();
             suma+=num;
             
         }
         prom=(double) suma/10;
         
        System.out.println("La suma total es:"+ suma);
        System.out.println("El promedio es:"+ prom);
   
    }
    
}
